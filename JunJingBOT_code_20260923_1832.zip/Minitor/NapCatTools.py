import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import random
import asyncio
import threading
import inspect
from pathlib import Path
from Websockets import NapCatBotConfig
import re
from NapCatAPI import NapCatAPIInterface as nc
from extension import Extension
import jieba
import json
from copy import deepcopy
from MusicServer import search_and_resolve_first_song

try:  # 兼容 run.py 的扁平 import 和 `Minitor.NapCatTools` 包内 import
    from forward_dedup import (
        CLAIM_FRESH_SECONDS,
        ForwardDedupStore,
        build_fingerprint,
        clean_group_ids,
        dedup_log,
        get_miniapp_info,
        get_multimsg_detail,
        get_multimsg_resid,
    )
    from forward_dedup import short_url
    from image_hash import IMAGE_HASH_AVAILABLE, hash_remote_images_report
except ImportError:  # pragma: no cover
    from Minitor.forward_dedup import (
        CLAIM_FRESH_SECONDS,
        ForwardDedupStore,
        build_fingerprint,
        clean_group_ids,
        dedup_log,
        get_miniapp_info,
        get_multimsg_detail,
        get_multimsg_resid,
    )
    from Minitor.forward_dedup import short_url
    from Minitor.image_hash import IMAGE_HASH_AVAILABLE, hash_remote_images_report


# ---- 从 paths_config.json 读取图片目录（适配 WSL / 跨平台） ----
def _load_imgs_dir() -> str:
    """加载图片目录配置，优先读 paths_config.json，fallback 到本地 imgs/"""
    config_path = Path(__file__).resolve().parent.parent / "paths_config.json"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        imgs_path = cfg.get("imgs_dir")
        if imgs_path:
            return imgs_path  # 直接用原始字符串（WSL 路径如 /mnt/d/...）
    except Exception:
        pass
    # Fallback：项目根目录下的 imgs/
    return str(Path(__file__).resolve().parent.parent / "imgs")


_IMGS_DIR = _load_imgs_dir()
# ----


# DEBUG = True


"""
用来存放BOT运行流程的主代码
"""


class MessageProcessor:
    def __init__(self, config: NapCatBotConfig, rws=None):
        self.extraconfig = {"tokenizer": False, "recent": True}
        self.ifs = image_forward_service(self)
        self.config = config
        # 反向 WS 模式：传入 NapCatReverseWS 共享连接；否则用 config 自建正向连接
        self.nc = nc(rws if rws is not None else config)
        self._rws = rws
        self.extension = Extension()
        self.user_id: str = None
        self._agent = None
        # self.sllm = None  # 后台线程惰性初始化
        self.campus_assistant = None  # 校园网助手，后台线程惰性初始化
        self._agent_ready = threading.Event()
        self._connect_lock = asyncio.Lock()  # 防止并发重复建连
        self._heartbeat_task: asyncio.Task = None
        self._checkpoint_save_task: asyncio.Task = None
        self.check_point: dict = {}
        self._dedup_store: ForwardDedupStore = None  # 转发去重指纹库（惰性创建）
        # 后台线程预加载 AI Agent + SLLM，不阻塞主线程
        self._agent_thread = threading.Thread(target=self._init_agent_bg, daemon=True)
        self._agent_thread.start()

    async def process_message(self, event, is_recover=False):

        DEBUG = False
        # 每条消息进来立即记录断点（崩了也知道处理到哪条了）
        if event.get("message_type") == "group":
            self.check_point[str(event.get("group_id"))] = event

        message_id = event["message_id"]
        user_id = event["user_id"]
        # raw_msg = event["raw_message"]

        if await self.auto_forward(
            event=event,
            groupid_list=[
                1054955587,
                1079845768,
                320955551,
                569117421,
                662802665,
                973208344,
                949950852
            ],
            target_groupid=[1079845768, 1054955587, 320955551],
            dedup=True,
            is_recover=is_recover,
            auto_img_forward_from_bot={'enable': True, 'bot_id_list': [3282647559, 2027241761,3181349085]},
        ):
            return
        # 关键词快速匹配（不走 AI，省 token）

        pattern_config = [
            {
                "regex": r"(男娘|南梁|nn)",
                "solution": self.send_message,
                "params": {
                    "message": "哪有男娘",
                    "filter": {"type": "ban", "data": ["895977823", "1032125562"]},
                },
            },
            {
                "regex": r"女装",
                "solution": self.send_message,
                "params": {"message": ["看看女装", "羡慕女装"]},
            },
            # {
            #     "regex": r"药娘",
            #     "solution": self.send_img,
            #     "params": {"img_addr": f"{_IMGS_DIR}/img01.jpg", "summary": "死人妖"},
            # },
            {
                "regex": r"(月抛|约炮|(月|约|🈷️)(吗|么|嘛|🐴|🐎))",
                "solution": self.send_img,
                "params": {
                    "img_addr": f"{_IMGS_DIR}/月抛找我.png",
                    "summary": "月抛找我",
                },
            },
            {
                "regex": r"妈妈(?!])",
                "solution": self.send_img,
                "params": {"img_addr": f"{_IMGS_DIR}/妈妈.gif", "summary": "妈妈"},
            },
            {
                "regex": r"老大(?!])",
                "solution": self.send_img,
                "params": {"img_addr": f"{_IMGS_DIR}/老大.gif", "summary": "老大？"},
            },
            {
                "regex": r"抱",
                "solution": self.send_img,
                "params": {"img_addr": f"{_IMGS_DIR}/要抱.gif", "summary": "要抱"},
            },
            {
                "regex": r"(jjcn|dsn|dkn|顶死你|顶哭你|((jj|唧唧)(草|凿|燥|糙)(你|泥)))",
                "solution": self.send_img,
                "params": {"img_addr": f"{_IMGS_DIR}/速来.jpg", "summary": "速来"},
            },
            {
                "regex": r"(看看脚|白丝)",
                "solution": self.send_img,
                "params": {"img_addr": f"{_IMGS_DIR}/脚.gif", "summary": "脚"},
            },
            {"regex": r"historydebug", "solution": self.get_long_history_test},
            {"regex": r"export", "solution": self.export},
            {"regex": r"set_tokenizer", "solution": self.set_tokenizer},
            {"regex": r"ocr", "solution": self.ocr},
            {"regex": r"img_fd ", "solution": self.img_forward_create_task},
            {"regex": r"fabric", "solution": self.fabric},
            {"regex": r"(我想听|MUSIC_GET|GETMUSIC)","solution":self.GetMusic},
        ]
        if not is_recover:
            asyncio.create_task(
                self.pattern_match(event=event, pattern_config=pattern_config)
            )

        # if await self.pattern_match(
        #     event=event,
        #     pattern_config=[
        #         {"regex": r"校园网", "solution": self.Check_Campus_NetWoerk}
        #     ],
        # ):
        #     return

        # 被 @ 时 → 交给 AI Agent 处理
        # return
        ated_user = await self.is_AT(event=event, user_id=[self.user_id])
        if ated_user:
            # 去除 CQ 码，提取纯文本
            clean_text = self.get_clean_context(event, True)
            match = re.match(r"^历史", clean_text)
            if match:
                DEBUG and print("SkipLLM:Clean_text:", clean_text)
                await self.history_solution(event)
                return
            # 构建上下文
            thread_id = (
                f"group_{event['group_id']}"
                if event["message_type"] == "group"
                else f"private_{user_id}"
            )
            iclhistory = None
            if self.extraconfig["recent"]:
                await self._ensure_connected()
                iclhistory = await self.get_history_msg(
                    event, reverse_order=True, message_seq=event["message_seq"]
                )
                print(iclhistory)
            context = (
                (
                    f"当前是群聊，群号 {event['group_id']}，"
                    f"发消息的用户 QQ 号是 {user_id}，消息 ID 是 {message_id},AT的对象的QQ号是{ated_user},你的QQ号是{self.user_id},主人的QQ号是{'1013098110'}"
                    if event["message_type"] == "group"
                    else f"当前是私聊，用户 QQ 号是 {user_id}"
                ),
                f"历史消息如下:{str(iclhistory)}" if iclhistory else "",
            )
            isDom = "{isDom:true}" if user_id == 1013098110 else "{isDom:false}"
            DEBUG and print(str(user_id) + isDom)
            DEBUG and print(f"[AI] 用户 {user_id} 提问: {self.generate_structed_message_to_creat_context(event=event,isOCR=True)}")
            totoal_msg = await self.generate_structed_message_to_creat_context(
                event=event
            )
            reply = await self.agent.chat(
                event=event,
                user_message=isDom + totoal_msg,
                thread_id=thread_id,
                extra_context=context,
            )
            DEBUG and print(f"[AI] 回复: {reply}")

            # Agent 如果调用了 send_xxx 工具，消息已发出；
            # 如果 Agent 只是返回文本，我们需要手动发送。
            # 判断：如果 reply 不为空且不是工具返回的"已成功发送"类消息
            # 注意: chat() 在异常/空回复时返回 None，天然被 if reply 过滤
            if reply == "__NETWORK__":
                self.send_message(event=event, message="校园网升级，校园网助手取消")
                # return
                # 主 Agent 判定为校园网问题，转交校园网助手
                await self._route_to_campus_assistant(
                    event, clean_text, iclhistory=iclhistory
                )
            elif reply == "__SILENT__":
                # 主 Agent 判定为不需要回复，静默处理
                return
            elif reply and "已成功发送" not in reply:
                await self.send_message(event, reply)
                return

    async def ocr_and_send(self, group_id, url):
        ocr_answer = await self.extension.napcat_ocr(url)
        await self._ensure_connected()
        await self.nc.send_group_message(group_id=group_id, message=ocr_answer["text"])

    def get_url(self, msg_event) -> list[str]:
        res = []
        for item in msg_event.get("message", []):
            item_type = item.get("type", "")
            if item_type != "image":
                continue
            url = (item.get("data") or {}).get("url")
            if not url:
                continue
            res.append(url)
        return res

    def is_contain_image(self, msg_event) -> bool:
        for item in msg_event.get("message", []):
            item_type = item.get("type", "")
            if item_type == "image" and not item.get("data", {}).get("summary"):
                return True
        return False

    def is_contain_video(self, msg_event) -> bool:
        for item in msg_event.get("message", []):
            item_type = item.get("type", "")
            if item_type == "video":
                return True
        return False

    async def image_forward_processor(self, event, target_id_list, msg_type="group"):
        if not self.is_contain_image(event):
            return
        group_id = event["group_id"] if event.get("message_type") == "group" else None
        if msg_type == "group":
            for target_id in target_id_list:
                if target_id == group_id:
                    continue
                await self._ensure_connected()
                await self.nc.forward_group_single_msg(
                    group_id=target_id, message_id=event["message_id"]
                )
            return
        if msg_type == "private":
            for target_id in target_id_list:
                await self._ensure_connected()
                await self.nc.forward_friend_single_msg(
                    user_id=target_id, message_id=event["message_id"]
                )

    async def image_forward_batch_processor(self, event, ret_info: list):
        if not self.is_contain_image(event) or self.is_contain_video(event):
            return
        ret_info.append(
            {
                "type": "node",
                "data": {
                    "uin": 234559943,
                    "name": "N552AA🍥🍜🍣🍕💊🍫",
                    "content": event.get("message", "消息丢失喵"),
                },
            }
        )

    async def fabric(self, event):
        clean_message = self.get_clean_context(event)
        pat = r"\[qq:(\d+)\].*?\[context:(.*)\]"
        match = re.search(pat, clean_message, re.S)
        name_match = re.search(r"\[name:([^\]]*)\]", clean_message)
        if not match:
            return
        if event.get("message_type") == "group":
            await self._ensure_connected()
            await self.nc.send_group_forward_msg(
                group_id=event.get("group_id"),
                messages=[
                    {
                        "type": "node",
                        "data": {
                            "uin": int(match.group(1)),
                            "name": name_match.group(1) if name_match else "QQ用户",
                            "content": [
                                {"type": "text", "data": {"text": match.group(2)}}
                            ],
                        },
                    }
                ],
            )
            return
        return

    async def GetMusic(self, event):
        clean_msg = self.get_clean_context(event)
        match = re.search(r"\[([^\]]*)\]",clean_msg)
        if not match:
            return
        query = match.group(1)
        res = search_and_resolve_first_song(query)
        url = res.get("music_url")
        print(f"[GetMusic] query={query}, url={url}")
        await self._ensure_connected()
        await self.nc.send_group_message(
            group_id=event.get("group_id"), message=[{"type": "record", "data":{"url": url}}]
        )

    async def image_forward_batch(
        self, group_id, target_id_list, begin_id, end_id, msg_type
    ):
        message_content = []
        await self.get_long_history_only_processor(
            group_id=group_id,
            start_id=begin_id,
            end_id=end_id,
            processor=self.image_forward_batch_processor,
            params={"ret_info": message_content},
        )

        if msg_type == "group":
            for target_id in target_id_list:
                if target_id == group_id:
                    continue
                await self._ensure_connected()
                await self.nc.send_group_forward_msg(
                    group_id=target_id, messages=message_content
                )
            return
        if msg_type == "private":
            return
            for target_id in target_id_list:
                await self._ensure_connected()
                await self.nc.forward_friend_single_msg(
                    user_id=target_id, message_id=event["message_id"]
                )

    async def image_forward(self, group_id, target_id_list, begin_id, end_id, msg_type):
        await self.get_long_history_only_processor(
            group_id=group_id,
            start_id=begin_id,
            end_id=end_id,
            processor=self.image_forward_processor,
            params={"target_id_list": target_id_list, "msg_type": msg_type},
        )

    async def ocr(self, event):
        reply_id = self.is_reply(event)
        if not reply_id:
            return
        await self._ensure_connected()
        res = await self.nc.get_message(message_id=reply_id)
        msg_event = res.get("data", {})

        url_list = self.get_url(msg_event)

        for url in url_list:
            asyncio.create_task(self.ocr_and_send(group_id=event["group_id"], url=url))
        return

    async def img_forward_create_task(self, event):
        clean_msg = self.get_clean_context(event=event)
        rpy = self.is_reply(event)
        target_group_id_list = None
        match = re.search(r"(-g|-group) (\d+)", clean_msg)
        if match:
            target_id = int(match.group(2))
            await self.ifs.create_task(
                group_id=event["group_id"], target_id_list=[target_id], msg_type="group"
            )
        else:
            match = re.search(r"(-u|-user) (\d+)", clean_msg)
            if match:
                target_id = int(match.group(2))
                await self.ifs.create_task(
                    group_id=event["group_id"],
                    target_id_list=[target_id],
                    msg_type="private",
                )
            else:
                match = re.search(r"(-a|-auto)", clean_msg)
                if match:
                    target_group_id_list = [
                        1079845768,
                        1054955587,
                        320955551,
                        973208344,
                    ]
                    await self.ifs.create_task(
                        group_id=event["group_id"],
                        target_id_list=target_group_id_list,
                        msg_type="group",
                    )

        match_1 = re.search(r"(-begin|-b)", clean_msg)
        if match_1:
            await self.ifs.set_begin_id(
                group_id=event["group_id"], begin_id=rpy or event["message_id"]
            )
        match_2 = re.search(r"(-end|-e)", clean_msg)
        if match_2 and match_1:
            await self.ifs.set_end_id(
                group_id=event["group_id"], end_id=event["message_id"]
            )
        elif match_2:
            await self.ifs.set_end_id(
                group_id=event["group_id"], end_id=rpy or event["message_id"]
            )
        return

    async def is_AT(self, event: dict, user_id: list[str]) -> list | None:
        """检查消息是否包含@指定用户"""
        temp = []
        info = event.get("message", [])
        for item in info:
            item_type = item.get("type", "")
            if item_type != "at":
                continue
            qq_id = str((item.get("data") or {}).get("qq", ""))
            if qq_id in user_id and qq_id not in temp:
                temp.append(qq_id)
        return temp

    # async def get_message_history(
    #     self, message_id: int
    # ) -> dict["context":str, "index":int]:
    #     """获取指定消息的历史记录"""
    #     await self._ensure_connected()
    #     event = await self.nc.get_message(message_id)
    #     raw_msg = event["data"]["raw_message"]
    #     match = re.match(r"\[CQ:reply,id=(\d+)\]", raw_msg)
    #     if match:
    #         reply_msg_id = int(match.group(1))
    #         clean_msg = re.sub(r"^\[CQ:reply,id=\d+\]", "", raw_msg).strip()
    #         temp = await self.get_message_history(reply_msg_id)
    #         return {
    #             "context": temp["context"] + "\n" + str(temp["index"] + 1) + clean_msg,
    #             "index": temp["index"] + 1,
    #         }
    #     else:
    #         return {"context": "1" + raw_msg, "index": 1}

    async def get_group_latest_msg(self, group_id):
        await self._ensure_connected()
        event = await self.nc.get_group_msg_history(
            group_id=group_id, count=1, reverse_order=True
        )
        messages = event["data"]["messages"]
        if not messages:
            print(f"[警告] 群 {group_id} 暂无消息或无法访问")
            return None
        return messages[0]

    async def _ensure_connected(self):
        """确保 API WebSocket 已连接且 reader 存活（带锁，自动重连）"""
        async with self._connect_lock:
            # 检查 reader 是否还活着（连接可能已异常断开）
            reader_dead = (
                self.nc._reader_task is not None and self.nc._reader_task.done()
            )
            if reader_dead:
                # 等待 reader 的 finally 清理完成
                try:
                    await self.nc._reader_task
                except Exception:
                    pass
                self.nc._reader_task = None
            if self.nc._ws_conn is None or self.nc._reader_task is None:
                await self.nc.connect()

    async def send_message(self, event, message):
        """根据事件类型发送消息"""
        if isinstance(message, list):
            n = len(message)
            index = random.randint(0, n - 1)
            message = message[index]

        if self.extraconfig["tokenizer"]:
            message = self.tokenizer(message)

        await self._ensure_connected()
        if event["message_type"] == "group":
            await self.nc.send_group_message(
                group_id=event["group_id"], message=message
            )
            asyncio.create_task(self.check_point_active_get(event["group_id"]))
        elif event["message_type"] == "private":
            await self.nc.send_private_message(
                user_id=event["user_id"], message=message
            )

    async def check_point_active_get(self, group_id):
        await self._ensure_connected()
        latest_msg = await self.get_group_latest_msg(group_id)
        if latest_msg:
            self.check_point[f"{group_id}"] = latest_msg

    async def send_img(self, event, img_addr, summary="君景发图"):
        """根据事件类型发送消息"""
        if isinstance(img_addr, list):
            n = len(img_addr)
            index = random.randint(0, n - 1)
            img_addr = img_addr[index]

        await self._ensure_connected()
        if event["message_type"] == "group":
            await self.nc.send_group_img(
                group_id=event["group_id"], img_addr=img_addr, summary=summary
            )
            asyncio.create_task(self.check_point_active_get(event["group_id"]))
        elif event["message_type"] == "private":
            await self.nc.send_private_img(
                user_id=event["user_id"], img_addr=img_addr, summary=summary
            )

    async def history_solution(self, event):
        message_id = event["message_id"]
        history = await self.get_message_history(message_id)
        print(history)
        await self.send_message(event, history["context"])

    def get_clean_context(self, event, keepAt=False) -> str:
        DEBUG = True
        context = ""
        for item in event.get("message", []):
            msg_type = item.get("type", "")
            if msg_type == "text":
                context += (item.get("data") or {}).get("text", "")
                continue
            if msg_type == "image":
                context += "图片"
                context += (item.get("data") or {}).get("summary", "")
                continue
            if keepAt and msg_type == "at":
                qq_id = (item.get("data") or {}).get("qq", "all")
                context += f"[CQ:at,qq={qq_id}]"
        DEBUG and print(context)
        return context

        

    async def pattern_match(self, event, pattern_config: list[dict[str, any]]):
        clean_msg = self.get_clean_context(event)
        ret: bool = False
        for pattern in pattern_config:
            solution = pattern.get("solution")
            regex = pattern.get("regex")
            if not solution or not regex:
                continue
            params = pattern.get("params", {})
            filter = params.pop("filter", None)
            if filter:
                if filter.get("type") == "ban":
                    if str(event.get("group_id")) in filter.get("data"):
                        continue
            if re.search(regex, clean_msg, re.I):
                # 自动检测 solution 是否需要 event 参数
                sig = inspect.signature(solution)
                if "event" in sig.parameters:
                    asyncio.create_task(solution(event=event, **params))
                else:
                    asyncio.create_task(solution(**params))
                ret = True
                continue
                # return True
        return ret

    async def read_check_point(self, user_id):
        file_name = str(
            Path(__file__).resolve().parent.parent / "check_point" / f"{user_id}.json"
        )
        try:
            with open(file_name, mode="r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            print("FileNotFoundError")
            dir_path = os.path.dirname(file_name)
            os.makedirs(dir_path, exist_ok=True)
            with open(file_name, mode="w", encoding="utf-8") as f:
                json.dump({}, f, ensure_ascii=False, indent=4)
                return {}
        except:
            print("error")
        return {}

    async def _save_check_point(self):
        """将当前断点写入磁盘"""
        DEBUG = False
        try:
            file_name = str(
                Path(__file__).resolve().parent.parent
                / "check_point"
                / f"{self.user_id}.json"
            )
            os.makedirs(os.path.dirname(file_name), exist_ok=True)
            with open(file_name, "w", encoding="utf-8") as f:
                json.dump(self.check_point, f, ensure_ascii=False, indent=4)
            if self.check_point:
                DEBUG and print(
                    f"[断点保存] 已写入 {len(self.check_point)} 条断点到 {file_name}"
                )
        except Exception as e:
            print(f"[断点保存] 异常: {e}")

    async def recover_process(self, event, latest_msg_id=None):
        """回放断点消息：从最新消息往前翻，直到找到断点消息为止"""
        DEBUG = True
        group_id = event["group_id"]
        rid = event.get("real_id")
        real_seq = event.get("real_seq")
        if not rid and not real_seq:
            return
        remaining = 8  # 最多翻 8 页
        message_seq = latest_msg_id  # None = 从最新开始
        while remaining > 0:
            remaining -= 1
            await self._ensure_connected()
            history_list = await self.nc.get_group_msg_history(
                group_id=group_id, reverse_order=True, count=20, message_seq=message_seq
            )
            messages = history_list["data"]["messages"]
            if not messages:
                break

            # 记录本次传入的锚点，后面会覆盖 message_seq
            seq_for_this_page = message_seq

            # 翻页锚点 = 本批最旧的消息的 seq（下一次拉更旧的）
            message_seq = messages[0]["message_seq"]

            # 非首次调用：API 返回会包含锚点消息（上一批已处理），pop 掉避免重复
            if seq_for_this_page is not None:
                messages.pop(0)
            if not messages:
                break

            # 从最新→最旧遍历（reverse_order 返回升序 旧→新）
            for msg_event in reversed(messages):
                if (
                    msg_event.get("real_id") == rid
                    or msg_event.get("real_seq") == real_seq
                ):
                    DEBUG and print(f"[断点恢复] {group_id}找到断点消息 {rid}")
                    latest = await self.get_group_latest_msg(group_id)
                    if latest:
                        self.check_point[f"{group_id}"] = latest
                    return
                if msg_event.get("user_id") == self.user_id:
                    DEBUG and print(f"[断点恢复] 断点保存出错，检测到君景消息")
                    return
                    # 被踢期间的消息确实没处理过，走完整 process_message
                    # DEBUG and print(f'[断点恢复] 未找到断点 {rid}，处理消息 {msg_event.get("real_id")}')
                await self.process_message(event=msg_event,is_recover=True)
        print(f"[断点恢复] 未找到断点 {rid}，可能已被清理")

    async def recover_from_check_point(self):
        """深拷贝断点，创建协程回放（不阻塞主流程）"""
        DEBUG = True
        check_point = deepcopy(self.check_point)
        latest_msg_sqes = {}
        for key, value in check_point.items():
            temp = await self.get_group_latest_msg(group_id=key)
            if temp is None:
                DEBUG and print(f"[断点恢复] 群 {key} 无最新消息，跳过恢复")
                continue
            latest_msg_sqes[key] = {
                "message_seq": temp["message_seq"],
                "real_id": temp.get("real_id"),
                "real_seq": temp.get("real_seq"),
            }

        for key, value in check_point.items():
            if key not in latest_msg_sqes:
                continue
            DEBUG and print(f"[断点恢复] 创建恢复任务: {key}")
            DEBUG and print(f"[断点恢复] 最新消息 seq: {latest_msg_sqes[key]}")
            if latest_msg_sqes[key]["real_id"] == value.get(
                "real_id"
            ) or latest_msg_sqes[key]["real_seq"] == value.get("real_seq"):
                DEBUG and print(
                    f"[断点恢复] 最新消息已是断点消息 {latest_msg_sqes[key]}，无需回放"
                )
                continue
            asyncio.create_task(
                self.recover_process(
                    event=value, latest_msg_id=latest_msg_sqes[key]["message_seq"]
                )
            )
        # if check_point:
        #     await self._save_check_point()

    async def _checkpoint_save_loop(self):
        """后台每 10 秒将内存中的断点刷入磁盘"""
        while True:
            await asyncio.sleep(10)
            try:
                await self._save_check_point()
            except Exception as e:
                print(f"[断点保存] 写入失败: {e}")

    async def setuserid(self):
        # 确保已获取自己的 QQ 号
        if self.user_id is None:
            await self._ensure_connected()
            self.user_id = await self.nc.get_user_id()
            self.check_point = await self.read_check_point(self.user_id)
            print(f"[启动] user_id={self.user_id}, 加载断点 {len(self.check_point)} 个")
            # 启动断点定时保存任务
            self._checkpoint_save_task = asyncio.create_task(
                self._checkpoint_save_loop()
            )
        # 启动心跳保活任务
        self.start_heartbeat()
        return

    async def get_long_history_backward(self, group_id, start_id, end_id):
        DEBUG = False
        remaining = 20  # 最大搜索20次
        part = []
        DEBUG = True
        last_msg_id = start_id
        while remaining > 0:
            DEBUG and print("reamaining = ", remaining)
            await self._ensure_connected()
            icl_history = await self.nc.get_group_msg_history(
                group_id=group_id, message_seq=last_msg_id
            )
            last_msg_id = icl_history["data"]["messages"][-1]["message_seq"]
            icl_history["data"]["messages"].pop()
            part = icl_history["data"]["messages"] + part
            remaining -= 1
            for item in icl_history["data"]["messages"]:
                if item["message_seq"] == end_id:
                    return part
            if item["message_seq"] == end_id:
                return part
        DEBUG and print("NotFind")
        return part

    async def get_long_history_only_processor(
        self, group_id, start_id, end_id, processor, params
    ) -> None:
        remaining = 200  # 最大搜索200次
        DEBUG = True

        last_msg_id = start_id

        while remaining > 0:
            print("reamaining = ", remaining)
            await self._ensure_connected()
            icl_history = await self.nc.get_group_msg_history(
                group_id=group_id, message_seq=last_msg_id
            )
            last_msg_id = icl_history["data"]["messages"][-1]["message_seq"]
            last_msg = icl_history["data"]["messages"].pop()
            remaining -= 1
            for item in icl_history["data"]["messages"]:
                await processor(event=item, **params)
                if item["message_seq"] == int(end_id):
                    DEBUG and print("FIND")
                    return
            if last_msg_id == end_id:
                await processor(event=last_msg, **params)
                DEBUG and print("FIND")
                return
        return

    async def export(self, event):
        DEBUG = True
        message_id = self.is_reply(event)
        if not message_id:
            return False
        clean_msg = self.get_clean_context(event)
        match1 = re.search(r"(-group|-g) (\d+)", clean_msg)
        match2 = re.search(r"(-user|-u) (\d+)", clean_msg)
        if not match1 and not match2:
            DEBUG and print("Find no Target")
            return False
        if match1:
            target_group = int(match1.group(2))
        if match2:
            target_user_id = int(match2.group(2))
        end_id = event["message_id"]
        if match1:
            await self.get_long_history_only_processor(
                group_id=event["group_id"],
                start_id=message_id,
                end_id=end_id,
                processor=self.auto_forward,
                params={
                    "groupid_list": [event["group_id"]],
                    "target_groupid": [target_group],
                },
            )
        if match2:
            print("Prepare to start export user")
            await self.get_long_history_only_processor(
                group_id=event["group_id"],
                start_id=message_id,
                end_id=end_id,
                processor=self.auto_forward,
                params={
                    "groupid_list": [event["group_id"]],
                    "task_userid": [target_user_id],
                },
            )
        return True

    def check_is_miniapp(self, msg_event: dict) -> dict:
        """检测小程序卡片，返回 title/desc/link/context（另含 appid/preview/url）"""
        return get_miniapp_info(msg_event)

    def check_is_multimsg_forward(self, msg_event: dict) -> str | None:
        """
        检测是否为新版合并转发JSON卡片
        :return: resid 字符串（是转发卡片时），否则 None
        """
        return get_multimsg_resid(msg_event)

    def check_is_old_forward(self, msg_event: dict) -> bool:
        """确定是不是旧版forward"""
        for seg in msg_event.get("message", []):
            if seg["type"] == "forward":
                return True
        return False

    def is_reply(self, msg_event: dict) -> int | None:
        for seg in msg_event.get("message", []):
            if seg["type"] == "reply":
                return seg["data"]["id"]
        return

    async def get_forward_try(self, msg_event: dict) -> str:
        res = ""
        for msg in msg_event.get("message", []):
            for seg in msg.get("data", {}).get("content", []):
                res += await self.generate_structed_message_to_creat_context(seg)
        return res

    async def generate_structed_message_to_creat_context(
        self, event, isOCR=False
    ) -> str:
        ###感觉可以做一个池来达到Cache命中的效果，因为需要持续去寻找转发消息，尤其是回复比较多的情况
        ###恰好有future可以达到，但是不适合该场景，因为访存和发包的时间肯定天差地别，发包还有网络压力 命中 or get_reply
        ###但是压力不大，效果不显著
        DEBUG = False
        temp = ""
        message_id = event["message_id"]
        DEBUG and print("获取sender")
        sender = event.get("sender") or {}
        user_id = event.get("user_id") or sender.get("user_id", "未知")
        name = sender.get("card") or sender.get("nickname", "未知")
        temp += (
            f"消息发送者{name}，其QQ号为{user_id},\t发送消息[message_id:{message_id}]:"
        )
        DEBUG and print(temp)
        mini_app_info = self.check_is_miniapp(event)
        if mini_app_info:
            return f"[这是一条小程序消息{mini_app_info.get('context')}]"
        if self.check_is_old_forward(event):
            DEBUG and print("转发模块tradition Begin")

            res = await self.nc.get_forward_msg({"message_id": message_id})

            if res["status"] == "failed":
                print(f"[转发模块tradition] 获取转发消息失败: {res.get('message')}")
                return await self.get_forward_try(event)
                # return f"retcode:{res.get('retcode')}"

            messages = res["data"]["messages"]
            ret = ""
            ret_temp = ""
            for message_event in messages:
                ret_temp = await self.generate_structed_message_to_creat_context(
                    message_event
                )
                if re.search(r"retcode:1200", ret_temp):
                    # DEBUG and print("DEBUG: 消息已过期或者为内层消息，无法获取转发消息")
                    print('\n\n\n\n')
                    print(message_event)
                    print('\n\n\n\n')
                    inner_content = message_event.get("content", [])
                    if not inner_content:
                        ret += "消息已过期或者为内层消息，无法获取转发消息"
                        # DEBUG and print("DEBUG: 消息已过期或者为内层消息，无法获取转发消息")
                        continue
                    for seg in inner_content:
                        ret += await self.generate_structed_message_to_creat_context(seg)
                    continue
                else:
                    ret += ret_temp
            temp += f"这是一条转发消息,内容如下[{ret}]\n"
            DEBUG and print("转发模块tradition End")
            return temp
        rid = self.check_is_multimsg_forward(event)
        if rid:
            DEBUG and print("转发模块Json Begin")
            await self._ensure_connected()
            res = await self.nc.get_forward_msg({"message_id": rid})
            if res["status"] == "failed":
                print(f"[转发模块Json] 获取转发消息失败: {res.get('message')}")
                return ""
            messages = res["data"]["messages"]
            ret = ""
            for message_event in messages:
                if (
                    not message_event.get("message")
                    or len(message_event["message"]) == 0
                ):

                    ret += "[这可能是嵌套的聊天记录，解析失败]"
                ret += await self.generate_structed_message_to_creat_context(
                    message_event
                )
            temp += f"这是一条转发消息,内容如下[{ret}]\n"
            DEBUG and print("转发模块json End")
            return temp
        reply_id = self.is_reply(event)
        if reply_id:
            await self._ensure_connected()
            res = await self.nc.get_message(message_id=reply_id)
            if res["status"] == "failed":
                return ""
            message = res["data"]
            ret = ""
            ret += await self.generate_structed_message_to_creat_context(message)
            temp += f"这是一条回复消息,被回复的内容如下[\n\t{ret}\n\t]\n"

        for seg in event.get("message", []):
            seg_type = seg.get("type", "")
            seg_data = seg.get("data") or {}
            if seg_type == "text":
                temp += seg_data.get("text", "")
                continue
            if seg_type == "image":
                temp += "图片"
                temp += seg_data.get("summary", "[]")
                url = seg_data.get("url")
                if not url:
                    continue
                if not isOCR:
                    temp += f'\n\t{{"url":{url}}}\n'
                    continue
                ocr_res = (await self.extension.napcat_ocr(url))["text"]
                temp += f"ocr结果{ocr_res}"
                continue
            if seg_type == "at":
                temp += f"[CQ:at,qq={seg_data.get('qq')}]"
        return temp

    async def set_tokenizer(self, event):
        raw_message = event["raw_message"]
        match = re.search(r"True", raw_message)
        if match:
            self.extraconfig["tokenizer"] = True
            await self.send_message(event=event, message="set tokenizer True")
            return True
        match = re.search(r"False", raw_message)
        if match:
            await self.send_message(event=event, message="set tokenizer True")
            self.extraconfig["tokenizer"] = False
            return True
        return False

    async def Check_Campus_NetWoerk(self, event):
        DELETED = False
        if DELETED:
            return
        clean_text = self.get_clean_context(event=event)
        await self._route_to_campus_assistant(event=event, clean_text=clean_text)

    async def _route_to_campus_assistant(self, event, clean_text: str, iclhistory=None):
        DELETED = False
        if DELETED:
            return
        DEBUG = True
        """当主 Agent 返回 __NETWORK__ 信号时，将对话转交校园网助手处理"""
        if self.campus_assistant is None:
            print("CampusAssistant 尚未加载完成，无法转交校园网问题")
            return
        DEBUG and print(f"[转交校园网助手] 用户提问: {clean_text}")
        await self._ensure_connected()
        reply = await self.campus_assistant.chat(
            message=clean_text,
            icl=(
                iclhistory
                if iclhistory is not None
                else await self.get_history_msg(event)
            ),
            group_id=event.get("group_id"),
        )
        if not reply:
            return
        if "[我不能回答]" in reply:
            DEBUG and print("校园网助手判定无法回答，跳过")
            return
        reply = reply.replace("[我能回答]", "").strip()
        await self.send_message(event, reply)

    async def forward_single_msg(
        self, event, message_type=None, group_id=None, user_id=None
    ) -> bool:
        DEBUG = False
        if message_type == "group" and group_id is not None:
            await self._ensure_connected()
            await self.nc.forward_group_single_msg(
                group_id=group_id, message_id=event["message_id"]
            )
            await self.check_point_active_get(group_id)
            return True
        elif message_type == "private" and user_id is not None:
            await self._ensure_connected()
            await self.nc.forward_friend_single_msg(
                user_id=user_id, message_id=event["message_id"]
            )
            return True
        return False

    async def batch_forward_single_msg(
        self,
        event,
        target_groupid=[],
        task_userid=[],
        )-> int:
        DEBUG = False
        count = 0
        for group_id in target_groupid:
            if group_id == event.get("group_id"):
                continue
            asyncio.create_task(
                self.forward_single_msg(
                    event=event, group_id=group_id, message_type="group"
                )
            )
            count += 1
            DEBUG and print("Succeed Forward!")
        for user_id in task_userid:
            if user_id == event.get("user_id"):
                continue
            asyncio.create_task(
                self.forward_single_msg(
                    event=event, user_id=user_id, message_type="private"
                )
            )
            count += 1
            DEBUG and print("Succeed Forward!")
        return count


    async def auto_forward(
        self,
        event,
        groupid_list=None,
        userid_list=None,
        target_groupid=None,
        task_userid=None,
        dedup: bool = False,
        is_recover: bool = False,
        auto_img_forward_from_bot: dict = {},
    ) -> bool:
        """自动搬运转发。

        :param dedup: 是否启用「这条内容之前搬过没有」的检验，默认 False（不检验）。
                      启用后会先查指纹库（内容哈希精确命中和 SimHash 相似度），
                      纯图这类文本过少的转发还会额外算图片 aHash+dHash 双哈希
                      做二次校验。判定是**内容级**的，只有三种结果：
                      没搬过 → 搬运，并把目标群和事件所在群一起标记进库；
                      搬过了 + 该群已被标记 → 发【发过了喵】并结束；
                      搬过了 + 该群没被标记 → 直接结束（不搬运、也不发提示）。
                      旧版转发卡片本地提不出摘要时（raw 常缺失）会回查一次
                      get_forward_msg，用真实内容拼指纹，而不是直接放行。
        :param is_recover: True = 断点回放。这段消息是机器人没登录那段时间进来的，
                           从来没处理过，回放就是为了补搬 → **整道去重闸门都不拦**，
                           既不提前结束也不发【发过了喵】（回放不会重复搬运：
                           断点之后的消息 live 路径从没见过）。
        """
        DEBUG = False
        if groupid_list is None:
            groupid_list = []
        if userid_list is None:
            userid_list = []
        if target_groupid is None:
            target_groupid = []
        if task_userid is None:
            task_userid = []
        if event["message_type"] == "group":
            gid = event["group_id"]
            if gid not in groupid_list:
                if DEBUG:
                    DEBUG and print("GROUP_ID NOT CORRECT")
                return False
        elif event["message_type"] == "private":
            uid = event["user_id"]
            if uid not in userid_list:
                if DEBUG:
                    DEBUG and print("USER_ID NOT CORRECT")
                return False
        else:
            return False

        if auto_img_forward_from_bot.get("enable", False):
            # print(event.get('user_id'))
            # print(auto_img_forward_from_bot.get('bot_id_list', []))
            if event.get('user_id') in auto_img_forward_from_bot.get('bot_id_list', []) and self.is_contain_image(event):
                # print(f"Auto Forward Image from Bot: {event.get('user_id')}")
                await self.batch_forward_single_msg(event, target_groupid=target_groupid, task_userid=task_userid)
                return True
        
        miniapp_info = self.check_is_miniapp(event)
        match = (
            self.check_is_old_forward(event)
            or self.check_is_multimsg_forward(event)
            or miniapp_info.get("title") == "哔哩哔哩"
        )
        if not match:
            DEBUG and print("Match Failed!")
            return False

        # ── 搬运去重闸门：搬过就不再搬，区别只在要不要发【发过了喵】 ──
        fingerprint: dict | None = None
        if dedup:
            fingerprint, matched = await self.forward_dedup_gate(
                event, miniapp_info=miniapp_info, target_groupid=target_groupid
            )
            # 断点回放（is_recover=True）不过这道闸：那段时间机器人没登录，
            # 这些消息**压根没处理过**，回放就是为了把它们补搬，
            # 所以既不发【发过了喵】也不提前结束（回放也不会重复搬运：
            # 断点之后的消息 live 路径从没见过）。
            if not is_recover:
                # 搬过了分两种：该群已被标记 → 发【发过了喵】；该群没被标记 → 直接结束
                if matched.get("decision") == "hit":
                    await self.send_img(
                        event=event,
                        img_addr=f"{_IMGS_DIR}/news.gif",
                        summary="[发过了喵]",
                    )
                    return True
                if matched.get("decision") == "skip":
                    return True

        forwarded = await self.batch_forward_single_msg(event, target_groupid=target_groupid, task_userid=task_userid)
        # 真的发出去了才登记指纹，避免“匹配但无处可转”的消息污染指纹库
        if fingerprint is not None and forwarded:
            await self.forward_dedup_record(
                fingerprint, event, target_groupid=target_groupid
            )
        return True

    def _get_dedup_store(self) -> ForwardDedupStore:
        """惰性创建指纹库：不启用去重就不会建库/开文件"""
        if self._dedup_store is None:
            self._dedup_store = ForwardDedupStore()
        return self._dedup_store

    @staticmethod
    def _dedup_marked_groups(target_groupid=None, event=None) -> list[str]:
        """这次要标记进库的群 = 目标群 + 事件所在群（纯数字、去重保序）。

        库里存的就是这一条：「**这条聊天记录被标记的群聊**」。搬进去的目标群算标记过，
        这份内容从哪个群搬出来的也算标记过 —— 两者都得有，判定才成立：
        - 只标目标群 → “同一份内容在原来那个群又发了一遍”认不出来（发不了【发过了喵】）；
        - 只标来源群 → “这份内容已经搬进过那几个群”又无从得知。
        """
        return clean_group_ids(
            list(clean_group_ids(target_groupid))
            + list(clean_group_ids([(event or {}).get("group_id")]))
        )

    @staticmethod
    def _dedup_cur_group(event) -> str:
        """“该群” = 本次事件所在的群，只用来判要不要发【发过了喵】。"""
        groups = clean_group_ids([(event or {}).get("group_id")])
        return groups[0] if groups else ""

    def _forward_kind(self, event, miniapp_info: dict | None = None) -> str | None:
        """判定转发类型，决定指纹怎么拼：miniapp / old_forward / multimsg"""
        info = miniapp_info if miniapp_info is not None else self.check_is_miniapp(event)
        if info.get("title") == "哔哩哔哩":
            return "miniapp"
        if self.check_is_old_forward(event):
            return "old_forward"
        # 用 detail 而不是 resid 判断：实测有 resid 为空的合并转发卡片
        if get_multimsg_detail(event):
            return "multimsg"
        return None

    @staticmethod
    def _forward_cq_id(event) -> str:
        """旧版转发卡片里 [CQ:forward,id=xxx] 的 id"""
        for seg in event.get("message", []) or []:
            if seg.get("type") == "forward":
                return str((seg.get("data") or {}).get("id") or "")
        return ""

    async def _fetch_forward_messages(
        self, event, kind: str = "old_forward"
    ) -> tuple[list, str]:
        """回查 get_forward_msg，取回转发记录里的真实内容（一次 API 调用）。

        以前这里回查的是 get_msg，指望补出卡片 raw（摘要在
        raw.elements[*].multiForwardMsgElement.xmlContent 里）。线上实测 raw 不可靠：
        实时推送的事件带 raw，断点回放的历史消息不带，而且带 raw 的那条也可能
        压根没有 multiForwardMsgElement（生产日志里 raw_head="{}" / raw_keys=[]）。
        改成直接查内容：返回的每条就是一整个消息事件（有 sender / raw_message /
        message），拼出来的 `浅奈: [图片]` 与卡片里的 <title> 是同一种东西，
        而且 raw 有没有都不影响。

        :return: (转发内容列表, 诊断信息)——诊断信息只写日志，拿不到内容时用来定位
        """
        candidates: list = []
        if kind == "multimsg":
            resid = get_multimsg_resid(event)
            if resid:
                candidates.append(resid)
        if event.get("message_id"):
            candidates.append(event["message_id"])
        cq_id = self._forward_cq_id(event)
        if cq_id:
            candidates.append(cq_id)
        # NapCat 对同一份转发内容是复用的（同一 resid 可能换成新消息 id），
        # 卡片消息 id 可能已失效 → 挨个试，第一次成功就用
        seen: set = set()
        marks: list = []
        for message_id in candidates:
            key = str(message_id)
            if not key or key in seen:
                continue
            seen.add(key)
            try:
                await self._ensure_connected()
                res = await self.nc.get_forward_msg({"message_id": message_id})
            except Exception as exc:
                print(f"[转发去重] 取转发内容异常(id={key}): {exc}")
                marks.append(f"{key}:exc")
                continue
            status = str((res or {}).get("status") or "none")
            messages = ((res or {}).get("data") or {}).get("messages") or []
            marks.append(f"{key}:{status}/{len(messages)}")
            if status != "failed" and messages:
                return list(messages), f"get_forward_msg[{','.join(marks)}]"
        # 所有候选 id 都没拿到 → 旧版转发有时把内容直接嵌在事件里
        # （`message[*].data.content[*]`，传统转发链路的 get_forward_try 就走这条路）。
        # 不补这一手的话，weak 指纹会一张图都拿不到，直接退化成纯文本判定。
        embedded = self._embedded_forward_records(event)
        if embedded:
            return embedded, f"embedded[content]{len(embedded)}"
        return [], f"get_forward_msg[{','.join(marks) or 'no_id'}] 空"

    @staticmethod
    def _embedded_forward_records(event) -> list[dict]:
        """从事件本身挖出内层转发记录（get_forward_msg 拿不到时的兜底）。

        旧版转发的每条记录也可能直接嵌在事件里：`message[*].data.content[*]`，
        每项一般还是一整个消息事件（有 sender / message），与传统转发链路的
        get_forward_try 一样。取不到任何一条就返回空列表。
        """
        records: list[dict] = []
        for seg in (event or {}).get("message") or []:
            if not isinstance(seg, dict):
                continue
            data = seg.get("data")
            content = data.get("content") if isinstance(data, dict) else None
            if isinstance(content, list):
                records.extend(item for item in content if isinstance(item, dict))
        return records

    @classmethod
    def _collect_image_urls(cls, node, urls: list[str], limit: int) -> None:
        """递归收集转发记录里的图片地址（NapCat 转发内容里是 type=image 的段）。

        取 `data.url`；有的版本只给 `data.file`（里面就是那条 http 地址），所以
        file 看着像链接时也收。非 http 的（file:// / 本地缓存路径）照样收进来，
        由调用方过滤并写进日志 —— "5 张图全下不动" 时才看得出是 url 本身不行。
        """
        if limit <= 0 or len(urls) >= limit:
            return
        if isinstance(node, dict):
            if node.get("type") == "image":
                data = node.get("data") or {}
                for key in ("url", "file"):
                    url = str(data.get(key) or "").strip()
                    if url and url not in urls:
                        urls.append(url)
                        break
            for value in node.values():
                cls._collect_image_urls(value, urls, limit)
        elif isinstance(node, (list, tuple)):
            for item in node:
                cls._collect_image_urls(item, urls, limit)

    async def _fetch_forward_image_hashes(
        self, event, kind: str, messages: list | None = None
    ) -> tuple[list[str], dict]:
        """图片双哈希校验：把转发记录里的图片算成 aHash+dHash 指纹。

        **只在文本指纹 weak（整段摘要只有 `昵称: [图片]`）时才调用**：
        这种转发的文本一模一样，分不出"同一条记录被再搬一次"和
        "另一个人发了同样张数的图"，只能靠图片本身来判。
        正常文字转发一次也不下载图片，零开销；取不到就安静返回空列表。

        :param messages: 已经取回的转发内容（gate 刚查过就直接复用，不用再打一次 API）
        :return: (图片双哈希列表, 诊断报告)。报告原样写进排查日志，用来回答
            「这次有没有找到图片 url / 每张图下载成功还是失败、为什么」。
            一张都没算出来时列表为空，判定会退回纯文本（weak 指纹此时只剩
            "谁 + 几张图"，可能误判，所以原因必须留在日志里）。
            取图路径：get_forward_msg（resid / 消息 id / CQ id 逐个试）→ 都不行
            就用事件里内嵌的 content（传统转发链路的 get_forward_try）。
        """
        if not IMAGE_HASH_AVAILABLE:
            return [], {"error": "pillow_missing", "url_cnt": 0, "urls": []}
        if not event:
            return [], {"error": "no_event", "url_cnt": 0, "urls": []}
        store = self._get_dedup_store()
        limit = store.img_max_count
        report: dict = {"img_max_count": limit}
        if messages is None:
            # gate 只在本地提不出摘要时才查过一次，这里是兜底（多打一次 API）
            messages, fetched = await self._fetch_forward_messages(event, kind)
            report["fwd"] = fetched
        report["messages"] = len(messages or [])
        # 收集上限放宽：非 http 的候选（file:// / 本地缓存路径）不该占掉下载名额
        raw_urls: list[str] = []
        self._collect_image_urls(messages or [], raw_urls, max(limit * 4, 20))
        urls = [u for u in raw_urls if u.startswith(("http://", "https://"))]
        skipped = [u for u in raw_urls if u not in urls]
        report["raw_url_cnt"] = len(raw_urls)
        if skipped:
            # 这些不是 http，下载不了 —— 写进日志，否则"没算到图片"看不出是 url 的问题
            report["skipped_cnt"] = len(skipped)
            report["skipped_urls"] = [short_url(u) for u in skipped[:10]]
        if not urls:
            report.update({"error": "no_image_url", "url_cnt": 0, "urls": []})
            return [], report
        hashes, img_report = await hash_remote_images_report(
            urls, timeout=store.img_timeout, max_count=limit
        )
        report.update(img_report)
        # 日志里同时留短链接（一眼看域名）和原始 url 全文（手动重试下载用）
        report["url_short"] = [short_url(u) for u in urls]
        report["items"] = [
            {**item, "url_short": short_url(item.get("url", ""))}
            for item in img_report.get("items", [])
        ]
        return hashes, report

    async def forward_dedup_gate(
        self, event, miniapp_info: dict | None = None, target_groupid=None
    ) -> tuple[dict | None, dict]:
        """搬运去重闸门。

        指纹只从事件本身提取（不含 sender/QQ 号/时间/消息 id），所以同一条内容
        被不同的人 repeat 转发也能识别。库里每行存的就是「**这条聊天记录（指纹）
        + 它被标记的群聊**」，标记集合 = 搬进去的目标群 ∪ 搬出来的来源群。
        判定是**内容级**的，一共三种结果：
        - 没搬过（matched 为空）→ 调用方搬运，由 forward_dedup_record 标记进库；
        - 搬过了 + 该群（事件所在群）在标记里 → matched["decision"] == "hit"
          → 调用方发【发过了喵】并结束；
        - 搬过了 + 该群不在标记里 → matched["decision"] == "skip"
          → 调用方直接结束（**不搬运、也不发提示**）。

        :param target_groupid: 本次准备搬进的目标群号列表
        :return: (指纹信息 | None, 判定结果)，指纹为 None 表示内容不足无法检验，照常转发
        """
        kind = self._forward_kind(event, miniapp_info)
        if not kind:
            dedup_log("gate_skip", event, reason="kind_none")
            return None, {}
        marked_groups = self._dedup_marked_groups(target_groupid, event)
        cur_group = self._dedup_cur_group(event)
        fingerprint = build_fingerprint(event, kind, miniapp_info=miniapp_info)
        first_pass = dict(fingerprint)  # 本地提取的结果，用于对照
        raw_source = "event"
        messages: list | None = None
        fwd_info = ""
        fwd_head = ""
        if kind == "old_forward":
            # type=forward（聊天记录卡片）在事件里既没有完整正文、也没有图片 url，
            # 而 weak 判据（正文文字数 < 图片数 x text_per_image）和图片双哈希都得靠
            # 真实内容，所以一律回查 get_forward_msg；取不到就退回卡片摘要那一路
            messages, fwd_info = await self._fetch_forward_messages(event, kind)
            if messages:
                fwd_head = json.dumps(
                    messages[:2], ensure_ascii=False, default=str
                )[:1200]
                rebuilt = build_fingerprint(
                    event,
                    kind,
                    miniapp_info=miniapp_info,
                    forward_messages=messages,
                )
                if rebuilt["text"]:
                    fingerprint = rebuilt
                    raw_source = "get_forward_msg"
        if not fingerprint["text"]:
            # 摘要都没解析出来，无从比较，照常转发
            dedup_log(
                "gate_skip",
                event,
                fingerprint=fingerprint,
                reason="empty_fingerprint",
                kind=kind,
                raw_source=raw_source,
                first_pass=first_pass,
                groups=marked_groups,
                cur_group=cur_group,
                fwd=fwd_info,
                fwd_head=fwd_head,
            )
            return None, {}
        fingerprint["raw_source"] = raw_source  # 供日志区分摘要从哪来
        # 正文文字数 < 图片数 x text_per_image（weak）时必须补一道图片双哈希：
        # 这类转发（少图模板聊天记录）文本常常一模一样，只看文本会误判成"搬过"。
        # 这里是整条链路上唯一会下载图片的地方，且只在 weak 时触发。
        images: list[str] = []
        img_report: dict = {}
        if fingerprint.get("weak"):
            images, img_report = await self._fetch_forward_image_hashes(
                event, kind, messages=messages
            )
            fingerprint["images"] = images
            # 报告跟着指纹走：hit/miss/record 那几行日志里也能看到图片这一路的结果
            fingerprint["img_report"] = img_report
            if fwd_info:
                img_report.setdefault("fwd", fwd_info)
            if not images:
                # 拿不到图 → weak 没法确认，本次当"没搬过"处理（日志里留原因）
                first_fail = next(
                    (i for i in img_report.get("items", []) if not i.get("ok")), {}
                )
                print(
                    f"[转发去重] weak 指纹（正文文字数 < 图片数 x text_per_image）"
                    f"没算到图片双哈希（{img_report.get('error') or 'unknown'}，"
                    f"url={img_report.get('url_cnt', 0)} 张，"
                    f"首个失败原因={first_fail.get('reason') or 'undefined'}），"
                    f"本次不按文本判定，照常搬运"
                )
            dedup_log("image", event, kind=kind, img_cnt=len(images), img=img_report)
        try:
            matched = await self._get_dedup_store().find(
                fingerprint["text"],
                fingerprint.get("weak", False),
                images=images,
                group_ids=marked_groups,
                cur_group=cur_group,
                # 关键：判定和认领在库里合成一次原子操作。否则同一份内容从 a 群、
                # b 群几乎同时进来时，两条都会查到"没搬过"，目标群里各发一遍。
                reserve=True,
                kind=kind,
                preview=fingerprint.get("preview", ""),
            )
        except Exception as exc:
            print(f"[转发去重] 查询指纹库失败，按未搬运处理: {exc}")
            dedup_log("error", event, stage="find", error=str(exc), kind=kind)
            return fingerprint, {}
        if matched:
            # 搬过了 → 只有两种结局：该群在标记里就发【发过了喵】，否则直接结束
            matched["decision"] = "hit" if matched.get("seen_here") else "skip"
            if matched["decision"] == "hit":
                why = "该群已被标记→发【发过了喵】"
            else:
                why = "该群没被标记→不搬运也不发提示"
            if matched.get("reason") == "claim_conflict":
                why += "（同内容刚被另一条消息认领）"
            elif matched.get("fresh"):
                why += f"（{CLAIM_FRESH_SECONDS} 秒内刚写过这条指纹）"
            print(
                f"[转发去重] 这条聊天记录搬过（{matched['reason']}，"
                f"相似度 {matched['similarity']}，第 {matched['hit_count']} 次，"
                f"kind={matched['kind']}，预览={matched['preview']!r}，"
                f"被标记的群={matched['group_ids']}，该群={cur_group or '(无)'}）"
                f"：{why}"
            )
            dedup_log(
                matched["decision"],  # action: hit（发提示）/ skip（什么都不做）
                event,
                fingerprint=fingerprint,
                first_pass=first_pass,
                kind=kind,
                raw_source=raw_source,
                img_cnt=len(images),
                groups=marked_groups,
                cur_group=cur_group,
                decision=matched["decision"],
                matched_by=matched["reason"],
                similarity=matched["similarity"],
                hit_count=matched["hit_count"],
                matched_preview=matched["preview"],
                matched_groups=matched["group_ids"],
                seen_here=matched.get("seen_here"),
                concurrent=matched.get("reason") == "claim_conflict",
                fresh=bool(matched.get("fresh")),
                fwd=fwd_info,
            )
            return fingerprint, matched
        # 没搬过 → 照常搬运，搬完由 forward_dedup_record 把群标记进库
        dedup_log(
            "miss",
            event,
            fingerprint=fingerprint,
            first_pass=first_pass,
            kind=kind,
            raw_source=raw_source,
            img_cnt=len(images),
            # weak（正文文字数 < 图片数 x text_per_image）必须靠图片确认，这里把
            # "本次到底算没算图"写进日志，便于事后对真实用例：img_cnt=0 且
            # img_required=true 就是"拿不到图，果断照常搬运"那一种。
            img_required=bool(fingerprint.get("weak")),
            groups=marked_groups,
            cur_group=cur_group,
            decision="forward",
            fwd=fwd_info,
            fwd_head=fwd_head,
        )
        return fingerprint, {}

    async def forward_dedup_record(
        self, fingerprint: dict, event, target_groupid=None
    ) -> None:
        """登记本次搬运：库里只存 8 字节 SimHash + 8 字节内容哈希，不存原文。

        同一份内容（content_hash 一致）只有一行，重复登记时把群并进原记录，
        所以「这条聊天记录被标记的群聊」是一直累积的。标记的群 = 目标群 + 事件所在群。

        注：真正管用的是闸门里的原子认领（forward_dedup_gate 调 find(reserve=True)），
        那一步已经把这些群写进库了；这里再登记一次是幂等的兜底，
        保证"真发出去了"这个事实最终一定落到库里。
        """
        images = fingerprint.get("images") or []
        marked_groups = self._dedup_marked_groups(target_groupid, event)
        cur_group = self._dedup_cur_group(event)
        try:
            fp_id = await self._get_dedup_store().record(
                text=fingerprint["text"],
                kind=fingerprint.get("kind", ""),
                group_ids=marked_groups,
                preview=fingerprint.get("preview", ""),
                weak=fingerprint.get("weak", False),
                images=images,
            )
            dedup_log(
                "record",
                event,
                fingerprint=fingerprint,
                fp_id=fp_id,
                raw_source=fingerprint.get("raw_source", "event"),
                img_cnt=len(images),
                groups=marked_groups,
                cur_group=cur_group,
            )
        except Exception as exc:
            print(f"[转发去重] 写入指纹失败: {exc}")
            dedup_log("error", stage="record", error=str(exc))

    async def get_long_history(self, group_id, message_id, remaining: int):
        if remaining <= 0:
            return []
        part = []
        DEBUG = True
        last_msg_id = message_id
        while remaining > 0:
            DEBUG and print("reamaining = ", remaining)
            await self._ensure_connected()
            icl_history = await self.nc.get_group_msg_history(
                group_id=group_id, message_seq=last_msg_id
            )
            last_msg_id = icl_history["data"]["messages"][0]["message_seq"]
            DEBUG and print(icl_history["data"]["messages"])
            DEBUG and print("last_msg_id", last_msg_id)
            icl_history["data"]["messages"].pop()
            part = icl_history["data"]["messages"] + part
            remaining -= 1

        return part

    async def get_history_msg(
        self, event=None, message_seq=None, count=6, reverse_order=False
    ) -> str:
        if not event:
            return ""
        await self._ensure_connected()
        if event.get("message_type") == "group":
            icl_history = await self.nc.get_group_msg_history(
                group_id=event["group_id"],
                reverse_order=reverse_order,
                message_seq=message_seq or event.get("message_seq", None),
                count=count,
            )
        elif event.get("message_type") == "private":
            icl_history = await self.nc.get_friend_msg_history(
                user_id=event["user_id"],
                reverse_order=reverse_order,
                message_seq=message_seq or event.get("message_seq", None),
                count=count,
            )
        else:
            return ""
        parts = []
        for ctx in icl_history["data"]["messages"]:
            parts.append(await self.generate_structed_message_to_creat_context(ctx))
        return "\n".join(parts)

    async def get_long_history_test(self, event):
        DEBUG = False
        DEBUG and print("enter History Debug")
        res = await self.get_long_history(
            group_id=event["group_id"], message_id=event["message_id"], remaining=10
        )
        DEBUG and print(res)
        DEBUG and print("end")

    def _init_agent_bg(self):
        """在后台线程中导入并初始化 QQBotAgent / SimpleLLM / CampusAssistant"""
        DEBUG = True
        DEBUG and print("后台预加载 AI Agent …")
        from Agent import QQBotAgent

        self._agent = QQBotAgent(napcat_api=self.nc, extension=self.extension, mp=self)
        # from Agent.SimpleLLM import SimpleChatModule as SLLM

        # self.sllm = SLLM()
        from Agent.CampusAssistant import CampusAssistant

        self.campus_assistant = CampusAssistant(message_processor=self)
        self._agent_ready.set()
        DEBUG and print("AI Agent + CampusAssistant 后台加载完成")

    async def _heartbeat_loop(self):
        """后台心跳协程：每 10~20 分钟（均匀分布）调用 get_login_info 保活"""
        DEBUG = False
        while True:
            interval = random.uniform(10 * 60, 20 * 60)  # 10~20 分钟
            await asyncio.sleep(interval)
            try:
                await self._ensure_connected()
                result = await self.nc.get_login_info()
                if DEBUG:
                    DEBUG and print(
                        f"[心跳] get_login_info 成功: {result.get('data', {}).get('nickname', 'unknown')}"
                    )
            except Exception as e:
                print(f"[心跳] 异常: {e}")

    def start_heartbeat(self):
        """启动心跳后台任务（需在事件循环中调用）"""
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            print("心跳任务已启动（间隔 10~20 分钟）")

    @property
    def agent(self):
        """返回 QQBotAgent，如果后台加载尚未完成则等待"""
        self._agent_ready.wait()
        return self._agent

    @staticmethod
    def tokenizer(text: str) -> str:
        """中文分词：基于 jieba 分词库，返回空格分隔的字符串。
        示例:
            tokenizer("我是独角兽。")
            → '我 是 独角兽 。'
        """
        return " ".join(jieba.cut(text))


class image_forward_service:
    def __init__(self, message_processor: MessageProcessor):
        self.ms = message_processor
        self.task_dict = {}
        self.lock = asyncio.Lock()

    async def create_task(self, group_id, target_id_list, msg_type):
        # 加锁，确定不会创建多个任务
        group_id = str(group_id)
        async with self.lock:
            if self.task_dict.get(group_id):
                print("Tasl has been created")
                return False
            self.task_dict[group_id] = {
                "begin_id": None,
                "end_id": None,
                "begin_event": asyncio.Event(),
                "end_event": asyncio.Event(),
            }
        asyncio.create_task(self._task_init(group_id, target_id_list, msg_type))
        return True

    async def _task_init(self, group_id, target_id_list, msg_type):
        group_id = str(group_id)
        data = self.task_dict.get(group_id)
        if not data:
            print("理论上不存在该问题")
            return
        await data["begin_event"].wait()
        await data["end_event"].wait()
        await self.ms.image_forward_batch(
            group_id, target_id_list, data["begin_id"], data["end_id"], msg_type
        )
        async with self.lock:
            self.task_dict.pop(group_id)
        return

    async def set_begin_id(self, group_id, begin_id):
        if not begin_id:
            return
        async with self.lock:
            group_id = str(group_id)
            data = self.task_dict.get(group_id)
            if not data:
                print("任务未创建！")
                return
            data["begin_id"] = begin_id
            data["begin_event"].set()
        return

    async def set_end_id(self, group_id, end_id):
        if not end_id:
            return
        async with self.lock:
            group_id = str(group_id)
            data = self.task_dict.get(group_id)
            if not data:
                print("任务未创建！")
                return
            data["end_id"] = end_id
            data["end_event"].set()
        return
